# DETHI7991

Project React + TypeScript sử dụng Vite.

## Mục đích
Ứng dụng này là front-end Vite/React/TypeScript. Hướng dẫn này giúp bạn đưa project lên **GitHub** và **deploy lên Vercel**.

---

## Cách chạy trên máy (kiểm tra trước khi push)
1. Cài Node.js (phiên bản LTS, ví dụ 18.x hoặc 20.x).
2. Mở terminal tại thư mục project, chạy:
   ```bash
   npm install
   npm run dev
